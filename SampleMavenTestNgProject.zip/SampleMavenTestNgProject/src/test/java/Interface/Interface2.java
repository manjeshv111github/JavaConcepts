package Interface;

public interface Interface2 {
	
	int y=20;
	void interface2();

}
