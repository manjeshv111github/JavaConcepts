package Interface;

public interface Interface1 {
	
	int x=10;
	void interface1();

}
