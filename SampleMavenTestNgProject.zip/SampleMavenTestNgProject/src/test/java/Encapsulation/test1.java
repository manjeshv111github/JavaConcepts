package Encapsulation;

public class test1 {
	

	public static void main(String[] args) {
		test2 obj = new test2();
		obj.setAge(35);
		int val =obj.getAge();
		System.out.println(val);

	}

}
