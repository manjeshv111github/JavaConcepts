
public class javasampleprogrames {
	
	static void star() {
		
		for(int i=1;i<=5;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println(" ");
		}
	}
		
		static void evenNum() {
			int j=1;
			for(int i=0;i<=100;i++) {
				System.out.println(i);
				i=i+1;
			}
			
		}
		
		static void oddNum() {
			int j=1;
			for(int i=1;i<=100;i++) {
				System.out.println(i);
				i=i+1;
			}
			
		}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		star();
		evenNum();
		oddNum();
	}

}
