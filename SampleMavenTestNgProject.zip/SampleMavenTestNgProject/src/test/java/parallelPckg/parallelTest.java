package parallelPckg;

import org.testng.annotations.Test;

public class parallelTest {
	
	@Test
	public void Test1() {
		System.out.println("im in Test1");
	}
	
	@Test
	public void Test2() {
		System.out.println("im in Test2");
	}
	
	@Test
	public void Test3() {
		System.out.println("im in Test3");
	}
	
	@Test
	public void Test4() {
		System.out.println("im in Test4");
	}

}
