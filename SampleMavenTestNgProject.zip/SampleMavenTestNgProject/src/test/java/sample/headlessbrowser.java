package sample;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class headlessbrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//ChromeOptions opt = new ChromeOptions();
		
		//opt.setHeadless(true);
		
		//opt.addArguments("window-size=1400,800");
		//opt.addArguments("headless");
		
		WebDriverManager.chromedriver().setup();
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://www.amazon.com");
		
		System.out.println(driver.getTitle());
		
	
		

	}

}
