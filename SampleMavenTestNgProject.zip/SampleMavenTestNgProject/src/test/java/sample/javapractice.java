package sample;

import java.util.Scanner;

public class javapractice {

	public static void main(String[] args) {

		// TypeCasting
		/*
		 * double dbl = 8.98; 
		 * int itn = (int)dbl; System.out.println(itn);
		 */
//------------------------------------------------------------------
		// Scanner
		/*Scanner sc = new Scanner(System.in);
		System.out.println("Enter Value");
		//int insc = sc.nextInt();
		String strsc = sc.nextLine();
		
		System.out.println(strsc+1);*/
//------------------------------------------------------------------		
		/*int a= 2;
		
		a+=2;
		
		System.out.println(a);*/
		//------------------------------------------------------------------		
		//print only even numbers till 100
		/*for(int i =0;i<100;i=i+2) {
			System.out.println(i);	
		}*/
		//------------------------------------------------------------------
		/*int i=0;
		while(i<5){
			System.out.println(i);
			i++;	
		}*/
		//------------------------------------------------------------------
		/*int[] arrint = {1,2,3};
		arrint[0]=4;
		int sze = arrint.length;
		System.out.println(arrint[0]);
		
		for(int i=0;i<sze;i++) {
			System.out.println(arrint[i]);
		}*/
		
		//------------------------------------------------------------------
		//charAt
		/*String name = "Apple";
		int len = name.length();
		System.out.println(name.charAt(0));
		
		for(int i=0;i<len;i++) {
			System.out.println(name.charAt(i));
		}*/
		//------------------------------------------------------------------
		
		//Substring
		/*String names = "Apple fruit";
		System.out.println(names.substring(3));
		System.out.println(names.substring(3,7));*/
		
		//------------------------------------------------------------------
		
		//Contains-is a casesensitive
		/*String names = "Apple fruit";
		System.out.println(names.contains("App"));*/
		//------------------------------------------------------------------
		
		//Equals
		/*String names1 = "Apple fruit";
		String names2 = "Orange fruit";
		String names3 = "Apple fruit";
		System.out.println(names1.equals(names2));
		System.out.println(names1.equals(names3));*/
		//------------------------------------------------------------------
		
		//Replace
		/*String names = "Apple fruit";
		System.out.println(names.replace("A", "V"));*/
		//------------------------------------------------------------------
		
		//Split
		/*String names = "Apple,Orange,Grapes";
		String splt[] = names.split(",");
		System.out.println(splt[2]);
		
		//for each loop
		for(String frt:splt) {
			System.out.println(frt);
		}*/
		//------------------------------------------------------------------
		
		//indexOf- gives number where char is present
		/*String names = "Apple fruit";
		System.out.println(names.indexOf("f"));*/
		//------------------------------------------------------------------
		
		//trim- remove spaces from the string
		/*String names = "  Apple fruit  ";
		System.out.println(names.trim());*/
		//------------------------------------------------------------------
		
		//toCharArray- used to convert string into array
		/*String s1="hello india";  
		char[] ch=s1.toCharArray();   
		for(int i=0;i<ch.length;i++){  
		System.out.println(ch[i]);  
		} */
		//------------------------------------------------------------------

	}
}
