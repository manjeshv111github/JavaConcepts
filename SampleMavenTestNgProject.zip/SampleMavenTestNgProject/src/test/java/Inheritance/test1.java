package Inheritance;

public class test1 {
	
	public static void main(String[] args) {
		test2 obj = new test2();
		obj.name="Man";
		obj.test2();
		obj.test3();
	}

}
