package Inheritance;

public class test3{
	protected String name;
	public void test3() {
		System.out.println(name +" im in test3");
	}

}
