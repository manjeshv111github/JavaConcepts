package Inheritance;

class A1{
	
	void a1() {
		System.out.println("Im in A1 class");
	}
}

interface interface1{
	
	int i=10;
	void interface1();
	
}

interface interface2{
	
	int j=20;
	void interface2();
}



public class Hybridinheritance extends A1 implements interface1,interface2 {
	
	//calling parent class and interface together
	
	@Override
	public void interface2() {
		System.out.println("Im in interface2");
		
	}

	@Override
	public void interface1() {
		
		System.out.println("Im in interface1");
		
	}
	
	public static void main(String[] args) {
		
		Hybridinheritance obj = new Hybridinheritance();
		
		obj.a1();
		obj.interface1();
		obj.interface2();

	}

	

}
