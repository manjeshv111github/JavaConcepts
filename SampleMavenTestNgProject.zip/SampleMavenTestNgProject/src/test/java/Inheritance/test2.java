package Inheritance;

public class test2 extends test3{

	public void test2() {
		System.out.println(name +" Im in test2");
	}
}
