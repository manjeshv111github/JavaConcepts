package JavaPractice;

public class overloading {

	//constructor overloading
	
	int int1;
	int int2;
	String x;
	String y;
	
	public overloading(int i,int j) {
		
		this.int1=i;
		this.int2=j;		
	}
	
	public overloading(String a,String b) {
		this.x=a;
		this.y=b;
	}
	
	public void coverloading() {
		System.out.println(int1+" "+int2);
	}
	
	//Method overloading
	
	public int sumNum(int sum1,int sum2) {
		
		int sum3 = sum1+sum2;
		
		return sum3;
	}
	
	public float sumNum(float sum1,float sum2) {
		
		float sum3=sum1+sum2;
		return sum3;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		overloading ovr = new overloading(5,6);
		overloading ovr1 = new overloading("St1","St2");
		ovr.coverloading();
		
		int mint1=ovr.sumNum(7, 5);
		float min2=ovr.sumNum(9.4f, 4.5f);
		
		System.out.println(mint1);
		System.out.println(min2);
	
	}

}
