package JavaPractice;

import java.util.Scanner;

public class loops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//for loop
	/*	Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number for multiplication table");
		int j=sc.nextInt();
		for(int i=1;i<=10;i++) {
			int k=j*i;
			System.out.println(k);
			
		}
		/*
		//while loop odd number
		
		/*int i=1;
		while(i<=10) {
			System.out.println(i);
			i=i+2;
		}*/
		
		//do while
		
		/*int i=1;
		do {
			System.out.println(i);
			i++;
		}while(i<=10);*/
		
		int h[]= {1,3,5,4,2,6};
		
		int len = h.length;
		
		for(int l=0;l<len;l++) {
			int k=h[l];
			System.out.println(k);
		}
		
		
	}

}
