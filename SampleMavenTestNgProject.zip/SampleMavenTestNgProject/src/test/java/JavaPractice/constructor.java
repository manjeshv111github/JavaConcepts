package JavaPractice;

class paramConstructor {
	//parameterized constructor
	paramConstructor(int a,int b){
		
		int c=a+b;
		
		System.out.println(c);
		
	}
}

public class constructor {
	//Non argument or parameterized constructor
	int a;
	String color="red";
	int num=10;
	public constructor() {
		a=7;
		System.out.println("Constructor created "+a);
	}
	
	public constructor(int num,String color) {
		this.color=color;
		this.num=num;
		System.out.println(num);
		System.out.println(color);
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		constructor obj = new constructor();
		constructor obj2 = new constructor(10,"orange");
		paramConstructor obj1 = new paramConstructor(2,3);
	}
	
	

}
