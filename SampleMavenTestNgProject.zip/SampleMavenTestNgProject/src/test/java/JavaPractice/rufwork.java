package JavaPractice;

import Interface.Interface1;
import Interface.Interface2;

public class rufwork implements Interface1,Interface2 {
	
	public void interface2() {
		System.out.println("Accessing from Interface2 "+y);
		
	}

	public void interface1() {
		
		System.out.println("Accessing from Interface1 "+x);
		
	}

	public static void main(String[] args) {

		rufwork intrfce = new rufwork();
		intrfce.interface1();
		intrfce.interface2();
		
		
		   
		
	}

}
