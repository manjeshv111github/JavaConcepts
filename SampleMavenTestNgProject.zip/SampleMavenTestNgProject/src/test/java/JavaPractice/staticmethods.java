package JavaPractice;

public class staticmethods {

	public void callme() {
		System.out.println("without static method");
	}
	
	public static void callme1() {
		System.out.println("static method");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		staticmethods obj = new staticmethods();
		obj.callme();//this is non static method hence object created to access
		callme1();//object not required hence it is static method
	}

}
