package JavaPractice;

public class exceptions {

	public static void main(String[] args) {
		
		//arithmetic exception
		
		//int i=100;
		//System.out.println(i/0); //throws arithmetic exception as it cannot devide from 0 reminder will be infinity
		
		//null pointer exception
		
		//String s=null;
		
		//System.out.println(s.length()); //throws null pointer exptions as it is null value we cannot take length of it
		
		//array outof boundary exptin
		
		int a[]= {1,2,3};
		System.out.println(a[9]);//Index 9 out of bounds for length 3
	
		

	}

}
