package JavaPractice;

public class methodOverloading {
	
	public static int maxOf(int a, int b) {
		
		if(a>b) {
			return a;
		}else {
			return b;
		}
	}
	
	public static float maxOf(float a,float b) {
		
		float c= a+b;
		
		return c;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		methodOverloading obj = new methodOverloading();
		int maxval = obj.maxOf(8, 6);
		System.out.println("Maximum of two numbers "+maxval);
		
		float maxfval = obj.maxOf(9.8f, 8.8f);
		System.out.println("Addition of two float numbers "+maxfval);
		
	}

}
