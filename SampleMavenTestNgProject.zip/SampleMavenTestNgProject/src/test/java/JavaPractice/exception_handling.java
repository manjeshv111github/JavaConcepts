package JavaPractice;

public class exception_handling {
	
	//if we dont use try block whole execution will stop
	//if we use try block only that perticular method will not execute but it will execute other methods
	
	static void test1() {
		try {
			int a=20;
			
			System.out.println(a/0);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}
	
	static void test2() {
		System.out.println("No erros");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		test1();
		test2();
		
		/*try {
			int a=20;
			
			System.out.println(a/0); //here it throws arithmetic exption so handling with try catch block
			String s=null;
			System.out.println(s.length());//throws error
			System.out.println(a/5); //without error 
		}
		catch(Exception e) {
			System.out.println("Error is "+e);
		}
		
		//finally block will execute even with or without errors also
		finally {
			System.out.println("Entered into Finally block"); 
		}*/
		

	}

}
