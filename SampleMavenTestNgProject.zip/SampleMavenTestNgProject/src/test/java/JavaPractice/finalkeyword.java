package JavaPractice;

public class finalkeyword {
	
	final int x=10;
	
	public final void fnl() {

		System.out.println("final keyword");
	}

}
