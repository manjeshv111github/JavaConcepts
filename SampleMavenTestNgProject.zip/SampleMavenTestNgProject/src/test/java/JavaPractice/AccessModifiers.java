package JavaPractice;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;

public class AccessModifiers {

	 static void removeDuplicates(String str)   
	    {     
	       
	    }   
	        
	      
	       
	
	
	
	public static void main(String[] args) {
		
		String countryArray[]
	            = { "India", "Pakistan", "Afganistan",
	                "Srilanka" };
	       
	        System.out.println("Array input: "
	                           + Arrays.toString(countryArray));
	 
	        List countryList = Arrays.asList(countryArray);
	        System.out.println("Converted elements: "
	                           + countryList);
	        
	        System.out.println(countryList.get(0));
	        System.out.println(countryList.get(1));
	        System.out.println(countryList.get(2));
		
	}

}
