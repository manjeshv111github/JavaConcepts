package Abstract;

import io.netty.util.internal.SystemPropertyUtil;

abstract class abs {
	
	protected int i=10; // can have anytype of modifiers
	
	static final int j=90; // explicitly used static final
	
	abstract void show(); // can have abstract method
	
	public void display() {                          // can have non abstract method
		System.out.println("Non abstract method");
	}
	
}

public class abstractclass extends abs {
	
	@Override
	void show() {
		System.out.println("abstract method");
		
	}


	public static void main(String[] args) {
		
		abstractclass abst= new abstractclass();
		
		abst.show();
		abst.display();
		
		abst.i=70;
		int k=abst.j;
		
		System.out.println(abst.i);
		System.out.println(k);

	}

	
}


